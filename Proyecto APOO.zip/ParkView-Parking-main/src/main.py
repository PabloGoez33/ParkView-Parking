from app import Manager

if __name__ == "__main__":
    app = Manager()
    app.mainloop()